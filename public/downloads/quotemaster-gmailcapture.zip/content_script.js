(() => {
  const GLOBAL_KEY = "__QUOTEMASTER_CAPTURE_STATE__";
  const SCRIPT_VERSION = "2026-07-10-panel-minimize-v1";
  const BACKGROUND_EVENT = "QUOTEMASTER_CAPTURE_READY";
  const FORCE_SYNC_EVENT = "QUOTEMASTER_FORCE_SYNC";
  const STORAGE_LAST_HASH_KEY = "quotemaster_last_sent_hash";
  const STORAGE_LAST_PAYLOAD_KEY = "quotemaster_last_sent_payload";
  const MIN_BODY_LENGTH = 24;
  const DEBOUNCE_MS = 850;
  const IS_TOP_FRAME = window.top === window;

  if (window[GLOBAL_KEY]?.version === SCRIPT_VERSION && window[GLOBAL_KEY]?.scanNow) {
    Promise.resolve(window[GLOBAL_KEY].scanNow("reinject")).catch((error) => {
      console.warn("[QuoteMaster] reinject scan failed:", error);
    });
    return;
  }

  if (window[GLOBAL_KEY]?.cleanup) {
    try {
      window[GLOBAL_KEY].cleanup();
    } catch (error) {
      console.warn("[QuoteMaster] previous capture cleanup failed:", error);
    }
  }

  let debounceTimer = null;
  let mutationObserver = null;
  let panel = null;
  let isPanelMinimized = false;
  let lastSeenHash = "";
  let lastDeliveredHash = "";
  let isSending = false;

  const senderEmailPattern = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;

  function normalizeText(value) {
    return String(value || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function collapseWhitespace(value) {
    return normalizeText(value).replace(/\s*\n\s*/g, "\n");
  }

  function stripUiPrefixes(value) {
    return normalizeText(value)
      .replace(/^(Subject|主题|主题词|Chat|Conversation|对话|邮件|Message)\s*[:：]\s*/i, "")
      .replace(/\s*[-|]\s*(Gmail|Outlook|WhatsApp|Mail)$/i, "")
      .trim();
  }

  function isVisible(node) {
    if (!node || !(node instanceof Element)) return false;
    const rect = node.getBoundingClientRect();
    const style = window.getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function formatLocalDateTime(input) {
    const date = input instanceof Date ? input : new Date(input);
    const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
    const pad = (n) => String(n).padStart(2, "0");

    return [
      safeDate.getFullYear(),
      "-",
      pad(safeDate.getMonth() + 1),
      "-",
      pad(safeDate.getDate()),
      " ",
      pad(safeDate.getHours()),
      ":",
      pad(safeDate.getMinutes()),
      ":",
      pad(safeDate.getSeconds()),
    ].join("");
  }

  function getLogoUrl() {
    try {
      return typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL("logo.png") : "";
    } catch (_error) {
      return "";
    }
  }

  function applyPanelMode() {
    if (!panel) return;
    const expanded = panel.querySelector("[data-qm-expanded]");
    const minimized = panel.querySelector("[data-qm-minimized]");
    if (expanded) expanded.style.display = isPanelMinimized ? "none" : "block";
    if (minimized) minimized.style.display = isPanelMinimized ? "flex" : "none";
    panel.style.width = isPanelMinimized ? "56px" : "420px";
    panel.style.maxWidth = isPanelMinimized ? "56px" : "calc(100vw - 32px)";
    panel.style.minWidth = isPanelMinimized ? "56px" : "320px";
    panel.style.height = isPanelMinimized ? "56px" : "auto";
    panel.style.padding = isPanelMinimized ? "0" : "0";
    panel.style.borderRadius = isPanelMinimized ? "18px" : "18px";
  }

  function createMiniPanel() {
    if (!IS_TOP_FRAME) return null;
    if (panel) {
      applyPanelMode();
      return panel;
    }

    panel = document.createElement("div");
    panel.id = "quotemaster-capture-dock";
    panel.style.cssText = [
      "position:fixed",
      "right:18px",
      "bottom:18px",
      "z-index:2147483647",
      "width:420px",
      "max-width:calc(100vw - 32px)",
      "min-width:320px",
      "border:1px solid rgba(15,23,42,.10)",
      "border-radius:18px",
      "background:rgba(255,255,255,.98)",
      "box-shadow:0 18px 50px rgba(15,23,42,.18)",
      "color:#0f172a",
      "font-family:Inter,Arial,\\5FAE\\8F6F\\96C5\\9ED1,sans-serif",
      "font-size:13px",
      "line-height:1.55",
      "box-sizing:border-box",
      "overflow:hidden",
    ].join(";");

    const logoUrl = getLogoUrl();
    const logoMarkup = logoUrl
      ? `<img src="${logoUrl}" alt="QuoteMaster" style="width:28px;height:28px;border-radius:9px;display:block;" />`
      : `<span style="width:28px;height:28px;border-radius:9px;background:#0f172a;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;">Q</span>`;

    panel.innerHTML = `
      <div data-qm-expanded>
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:14px 14px 12px;border-bottom:1px solid rgba(15,23,42,.08);background:#ffffff;">
          <div style="display:flex;align-items:flex-start;gap:10px;min-width:0;">
            <div style="position:relative;flex:none;">
              ${logoMarkup}
              <span data-qm-dot style="position:absolute;right:-2px;bottom:-2px;width:9px;height:9px;border-radius:999px;background:#64748b;border:2px solid #fff;display:inline-block;"></span>
            </div>
            <div style="min-width:0;">
              <div style="font-weight:800;color:#0f172a;letter-spacing:0;font-size:14px;">QuoteMaster 捕获助手</div>
              <div data-qm-title style="margin-top:1px;color:#64748b;font-size:12px;font-weight:600;">自动监听中</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;flex:none;">
            <button data-qm-sync type="button" style="height:32px;padding:0 11px;border:1px solid #cbd5e1;border-radius:10px;background:#0f172a;color:#fff;font-weight:800;font-size:12px;cursor:pointer;">手动同步</button>
            <button data-qm-minimize type="button" title="最小化" style="width:32px;height:32px;border:1px solid #e2e8f0;border-radius:10px;background:#fff;color:#475569;font-weight:900;font-size:18px;line-height:1;cursor:pointer;">−</button>
          </div>
        </div>
        <div style="padding:13px 15px 15px;background:#fff;">
          <div data-qm-status style="min-height:42px;color:#334155;font-size:13px;font-weight:650;white-space:normal;word-break:break-word;overflow-wrap:anywhere;line-height:1.65;">自动监听中。打开邮件详情页后，系统会在识别到正文时同步到业务线程。</div>
          <div style="margin-top:12px;display:flex;align-items:center;justify-content:space-between;gap:10px;color:#94a3b8;font-size:11px;">
            <span>邮箱 / WhatsApp / 手动同步</span>
            <span data-qm-mode>展开状态</span>
          </div>
        </div>
      </div>
      <button data-qm-minimized type="button" title="QuoteMaster 捕获助手" style="display:none;align-items:center;justify-content:center;width:56px;height:56px;border:1px solid rgba(15,23,42,.12);border-radius:18px;background:#fff;box-shadow:0 14px 34px rgba(15,23,42,.2);cursor:pointer;padding:0;position:relative;">
        ${logoMarkup}
        <span data-qm-mini-dot style="position:absolute;right:8px;bottom:8px;width:10px;height:10px;border-radius:999px;background:#64748b;border:2px solid #fff;"></span>
      </button>
    `;

    const syncButton = panel.querySelector("[data-qm-sync]");
    if (syncButton) {
      syncButton.addEventListener("click", () => {
        isPanelMinimized = false;
        applyPanelMode();
        scanNow("manual-ui").catch((error) => {
          console.warn("[QuoteMaster] manual dock sync failed:", error);
          setPanelState("error", "同步失败：请刷新页面后重试");
        });
      });
    }

    const minimizeButton = panel.querySelector("[data-qm-minimize]");
    if (minimizeButton) {
      minimizeButton.addEventListener("click", () => {
        isPanelMinimized = true;
        applyPanelMode();
      });
    }

    const minimizedButton = panel.querySelector("[data-qm-minimized]");
    if (minimizedButton) {
      minimizedButton.addEventListener("click", () => {
        isPanelMinimized = false;
        applyPanelMode();
      });
    }

    document.documentElement.appendChild(panel);
    applyPanelMode();
    return panel;
  }
  function setDockState(state, detail) {
    const node = createMiniPanel();
    if (!node) return;
    const dot = node.querySelector("[data-qm-dot]");
    const status = node.querySelector("[data-qm-status]");

    const presets = {
      idle: { dot: "#64748b", text: "自动监听中" },
      scanning: { dot: "#f59e0b", text: "正在扫描当前页面" },
      captured: { dot: "#22c55e", text: detail || "已同步" },
      duplicate: { dot: "#3b82f6", text: detail || "内容已同步" },
      empty: { dot: "#94a3b8", text: detail || "未识别到可同步内容" },
      error: { dot: "#ef4444", text: detail || "同步失败" },
    };

    if (!dot || !status) return;

    const preset = presets[state] || presets.idle;
    dot.style.background = preset.dot;
    status.textContent = preset.text;
  }

  function isKnownNonConversationPage() {
    const text = `${document.title || ""} ${location.hostname} ${location.pathname} ${location.hash}`.toLowerCase();
    return /module=welcome|welcomemodule|welcome\.|mail163_letter#module=welcome|#module=welcome/.test(text);
  }

  function hasMailUrlSignal() {
    if (isKnownNonConversationPage()) return false;
    const text = `${document.title || ""} ${location.hostname} ${location.pathname} ${location.hash}`.toLowerCase();
    return /mail|gmail|outlook|webmail|inbox|message|conversation|163\.com|126\.com|yeah\.net|qq\.com|exmail|aliyun|whatsapp|chat/.test(text);
  }

  function hasMailHeaderSignal() {
    const headerSelectors = [
      "span.gD[email]",
      "[email]",
      "a[href^='mailto:']",
      "[aria-label*='From' i]",
      "[aria-label*='Sender' i]",
      "[aria-label*='To' i]",
      "[aria-label*='Subject' i]",
      "[aria-label*='发件人']",
      "[aria-label*='寄件人']",
      "[aria-label*='收件人']",
      "[aria-label*='主题']",
      "time[datetime]",
      "[data-timestamp]",
    ].join(",");

    if (document.querySelector(headerSelectors)) return true;

    const visibleHeaders = [...document.querySelectorAll("header, [role='banner'], [class*='head' i], [class*='title' i]")]
      .filter(isVisible)
      .slice(0, 12);

    return visibleHeaders.some((node) => /\b(from|sender|to|cc|bcc|subject|date|sent|reply|forward)\b|发件人|寄件人|收件人|主题|日期|时间|回复|转发/i.test(getTextFromNode(node)));
  }

  function hasKnownMessageContainer() {
    return Boolean(
      document.querySelector(
        [
          "div.a3s.aiL",
          "div.a3s",
          "[role='article']",
          "article",
          "[data-pre-plain-text]",
          "[data-message-id]",
          "[data-testid*='msg' i]",
          "[data-testid*='message' i]",
          "[class*='mailContent' i]",
          "[class*='mail-content' i]",
          "[class*='readmail' i]",
          "[class*='message-body' i]",
        ].join(",")
      )
    );
  }

  function isLikelyConversationPage() {
    if (isKnownNonConversationPage()) return false;
    return hasMailUrlSignal() || hasMailHeaderSignal() || hasKnownMessageContainer();
  }

  function getTextFromNode(node) {
    return collapseWhitespace(node?.innerText || node?.textContent || "");
  }

  function parseTimestampCandidate(value) {
    if (!value) return null;
    const raw = String(value).trim();

    if (/^\d{10,13}$/.test(raw)) {
      const numeric = Number(raw);
      return new Date(raw.length === 10 ? numeric * 1000 : numeric);
    }

    const parsed = new Date(raw);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }

  function extractDocumentTitle(root) {
    const selectors = [
      '[data-testid*="subject"]',
      '[aria-label*="subject" i]',
      '[aria-label*="主题"]',
      'h1',
      'h2',
      'h3',
      '[role="heading"]',
      '.subject',
      '.mail-subject',
      '[data-testid="conversation-subject"]',
    ];

    for (const selector of selectors) {
      const node = root.querySelector(selector);
      if (!node || !isVisible(node)) continue;
      const text = stripUiPrefixes(getTextFromNode(node) || node.getAttribute?.("title") || "");
      if (text) return text;
    }

    return stripUiPrefixes(normalizeText(document.title || ""));
  }

  function detectSourceType(root) {
    const host = location.hostname.toLowerCase();
    const pageText = `${document.title || ""} ${location.href}`.toLowerCase();

    if (
      host.includes("whatsapp") ||
      pageText.includes("whatsapp") ||
      root.querySelector('[data-pre-plain-text], [data-testid="msg-container"], [data-testid*="conversation-panel"]')
    ) {
      return "WHATSAPP";
    }

    return "EMAIL";
  }

  function isIgnoredCaptureContainer(node) {
    if (!(node instanceof Element)) return true;

    return Boolean(
      node.closest(
        [
          "#quotemaster-capture-dock",
          "nav",
          "aside",
          "footer",
          "[role='navigation']",
          "[role='toolbar']",
          "[role='menubar']",
          "[role='menu']",
          "[role='listbox']",
          "[role='textbox']",
          "[contenteditable='true']",
          "form",
          "button",
        ].join(",")
      )
    );
  }

  function hasMostlyUiText(text) {
    const normalized = normalizeText(text);
    if (!normalized) return true;

    const uiHits = [
      "Inbox",
      "Sent",
      "Draft",
      "Spam",
      "Trash",
      "Archive",
      "Reply",
      "Forward",
      "Delete",
      "收件箱",
      "发件箱",
      "草稿",
      "垃圾邮件",
      "回复",
      "转发",
      "删除",
      "归档",
    ].filter((word) => normalized.includes(word)).length;

    return uiHits >= 5 && normalized.length < 900;
  }

  function looksLikeMessageBody(node) {
    const text = getTextFromNode(node);
    if (text.length < 80 || text.length > 50000) return false;
    if (hasMostlyUiText(text)) return false;

    const words = text.split(/\s+/).filter(Boolean);
    const emailLike = senderEmailPattern.test(text);
    const sentenceLike = /[.!?。！？]\s|[\r\n]/.test(text);
    const commerceLike = /\b(quote|quotation|price|target|sample|order|qty|quantity|MOQ|FOB|EXW|CIF|DDP|lead time|delivery|spec|requirement|invoice|payment|询价|报价|价格|样品|订单|数量|交期|规格|付款)\b/i.test(text);

    return words.length >= 10 && (sentenceLike || commerceLike || emailLike);
  }

  function collectGenericBodyRoots() {
    const scanRoots = [
      document.querySelector("[role='main']"),
      document.querySelector("main"),
      document.querySelector("[class*='read' i]"),
      document.querySelector("[class*='mail' i]"),
      document.body,
    ].filter(Boolean);

    const candidates = new Set();
    const selectors = [
      "article",
      "section",
      "div",
      "td",
      "[class*='content' i]",
      "[class*='body' i]",
      "[class*='message' i]",
      "[class*='mail' i]",
      "[class*='read' i]",
    ].join(",");

    for (const scanRoot of scanRoots) {
      scanRoot.querySelectorAll(selectors).forEach((node) => {
        if (!(node instanceof Element)) return;
        if (!isVisible(node) || isIgnoredCaptureContainer(node)) return;
        if (!looksLikeMessageBody(node)) return;

        const nodeTextLength = getTextFromNode(node).length;
        const childBody = [...node.children].some((child) => {
          return child instanceof Element && looksLikeMessageBody(child) && getTextFromNode(child).length > nodeTextLength * 0.72;
        });

        if (!childBody) candidates.add(node);
      });
    }

    return [...candidates].sort((a, b) => getTextFromNode(a).length - getTextFromNode(b).length);
  }

  function collectVisibleRoots() {
    const selectors = [
      'div.a3s.aiL',
      'div.a3s',
      '[role="article"]',
      'article',
      'article[role="article"]',
      '[data-message-id]',
      '[data-pre-plain-text]',
      '[data-testid*="msg-container"]',
      '[data-testid*="message"]',
      '[class*="content" i]',
      '[class*="body" i]',
      '[class*="message" i]',
      '[class*="read" i]',
      '[aria-label*="message" i]',
      '[aria-label*="邮件"], [aria-label*="郵件"]',
      '[data-testid="conversation-panel-messages"] > div',
    ];

    const candidates = new Set();

    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((node) => {
        if (node instanceof Element && isVisible(node)) {
          candidates.add(node);
        }
      });
    }

    collectGenericBodyRoots().forEach((node) => candidates.add(node));

    return [...candidates].sort((a, b) => {
      if (a === b) return 0;
      const position = a.compareDocumentPosition(b);
      if (position & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (position & Node.DOCUMENT_POSITION_PRECEDING) return 1;
      return 0;
    });
  }

  function scoreRoot(root) {
    const text = getTextFromNode(root);
    let score = Math.min(text.length / 50, 30);

    if (root.matches('div.a3s, div.a3s.aiL')) score += 12;
    if (root.matches('[role="article"], article')) score += 10;
    if (root.hasAttribute('data-message-id')) score += 8;
    if (root.hasAttribute('data-pre-plain-text')) score += 10;
    if (root.hasAttribute('data-testid')) score += 4;
    if (looksLikeMessageBody(root)) score += 8;
    if (root.matches("[class*='content' i], [class*='body' i], [class*='message' i], [class*='read' i]")) score += 4;
    if (/whatsapp/i.test(location.hostname) || /whatsapp/i.test(document.title)) score += 4;
    if (root.closest('[role="dialog"]')) score -= 20;
    if (root.closest('[contenteditable="true"]')) score -= 15;

    return score;
  }

  function pickConversationRoot() {
    const roots = collectVisibleRoots();
    if (!roots.length) return null;

    const scored = roots.map((root) => ({ root, score: scoreRoot(root) }));
    scored.sort((a, b) => a.score - b.score);

    const top = scored[scored.length - 1];
    if (!top || top.score < 10) return null;
    return top.root;
  }

  function extractSenderIdentity(root) {
    const selectors = [
      'span.gD[email]',
      'span[email].gD',
      '[email]',
      '[data-hovercard-id]',
      'a[href^="mailto:"]',
      '[aria-label*="From" i]',
      '[aria-label*="发件人"]',
      '[aria-label*="寄件人"]',
      '[aria-label*="Sender" i]',
      '[data-testid*="sender"]',
      '[data-testid*="from"]',
      '[data-testid*="chat-title"]',
    ];

    const ownEmailSet = new Set();
    document.querySelectorAll('[aria-label*="Google Account"], [aria-label*="Google 账户"], [aria-label*="Google 帐户"], [href*="SignOutOptions"]')
      .forEach((node) => {
        const value = [
          node.getAttribute?.('email'),
          node.getAttribute?.('data-hovercard-id'),
          node.getAttribute?.('aria-label'),
          node.getAttribute?.('title'),
          node.textContent,
        ].find((candidate) => candidate && senderEmailPattern.test(candidate));
        if (value) ownEmailSet.add(String(value).match(senderEmailPattern)[0].toLowerCase());
      });

    for (const selector of selectors) {
      const nodes = root.querySelectorAll(selector);
      for (const node of nodes) {
        if (!(node instanceof Element) || !isVisible(node)) continue;
        const attrs = [
          node.getAttribute('email'),
          node.getAttribute('data-hovercard-id'),
          node.getAttribute('title'),
          node.getAttribute('aria-label'),
          node.textContent,
        ];
        for (const attr of attrs) {
          if (!attr) continue;
          const match = String(attr).match(senderEmailPattern);
          if (match) {
            const email = match[0].toLowerCase();
            if (!ownEmailSet.has(email)) return email;
          }
        }
      }
    }

    // Fallback: use visible sender/contact label as a stable identity token for non-email web apps.
    const fallbackSelectors = [
      '[aria-label*="From" i]',
      '[aria-label*="发件人"]',
      '[aria-label*="寄件人"]',
      '[data-testid*="sender"]',
      '[data-testid*="chat-title"]',
      'header',
    ];

    for (const selector of fallbackSelectors) {
      const node = root.querySelector(selector);
      if (!node || !isVisible(node)) continue;
      const text = normalizeText(node.getAttribute?.('aria-label') || node.getAttribute?.('title') || getTextFromNode(node));
      if (text) return text;
    }

    return "";
  }

  function extractLocalTimestamp(root) {
    const timestampNodes = [
      root.querySelector('[data-timestamp]'),
      root.querySelector('time[datetime]'),
      root.querySelector('[title*="AM"], [title*="PM"], [title*="上午"], [title*="下午"]'),
      root.querySelector('[aria-label*="time" i], [aria-label*="时间"], [aria-label*="時間"]'),
    ].filter(Boolean);

    for (const node of timestampNodes) {
      const candidateValues = [
        node.getAttribute?.('data-timestamp'),
        node.getAttribute?.('datetime'),
        node.getAttribute?.('title'),
        node.getAttribute?.('aria-label'),
        node.textContent,
      ];

      for (const candidate of candidateValues) {
        const parsed = parseTimestampCandidate(candidate);
        if (parsed) return formatLocalDateTime(parsed);
      }
    }

    const bodyTimeNodes = [...root.querySelectorAll('time, [data-timestamp], [aria-label], [title]')];
    for (const node of bodyTimeNodes) {
      const values = [node.getAttribute?.('data-timestamp'), node.getAttribute?.('datetime'), node.getAttribute?.('title'), node.getAttribute?.('aria-label')];
      for (const value of values) {
        const parsed = parseTimestampCandidate(value);
        if (parsed) return formatLocalDateTime(parsed);
      }
    }

    return formatLocalDateTime(new Date());
  }

  function removeQuotedHistory(text) {
    const cutPatterns = [
      /\nOn .+ wrote:\s*$/im,
      /\n-----Original Message-----/im,
      /\nFrom:\s*.+$/im,
      /\nSent:\s*.+$/im,
      /\nTo:\s*.+$/im,
      /\nSubject:\s*.+$/im,
      /\n_{5,}\s*$/im,
      /\n-{2,}\s*Original Message\s*-{2,}/im,
    ];

    let cutIndex = -1;
    for (const pattern of cutPatterns) {
      const match = text.match(pattern);
      if (match && typeof match.index === 'number' && match.index >= 0) {
        cutIndex = cutIndex < 0 ? match.index : Math.min(cutIndex, match.index);
      }
    }

    const trimmed = cutIndex >= 0 ? text.slice(0, cutIndex) : text;
    return normalizeText(trimmed.replace(/\n>.+$/gm, ''));
  }

  function extractLatestBodyText(root) {
    const clone = root.cloneNode(true);

    clone.querySelectorAll([
      'blockquote',
      '.gmail_quote',
      '.gmail_signature',
      '[aria-hidden="true"]',
      'script',
      'style',
      '[contenteditable="true"]',
      '[style*="display: none"]',
      '[style*="display:none"]',
    ].join(',')).forEach((node) => node.remove());

    const text = getTextFromNode(clone);
    return removeQuotedHistory(text);
  }

  function makeSourceIdentity(sourceType, identity, title) {
    const cleanedIdentity = normalizeText(identity || '').toLowerCase();
    const cleanedTitle = normalizeText(title || '').toLowerCase();

    if (cleanedIdentity) return cleanedIdentity;
    if (cleanedTitle) return `${sourceType.toLowerCase()}:${cleanedTitle}`;
    return `${sourceType.toLowerCase()}:${location.hostname}`;
  }

  async function sha256Hex(value) {
    const input = new TextEncoder().encode(String(value || ''));

    if (globalThis.crypto?.subtle?.digest) {
      const digest = await globalThis.crypto.subtle.digest('SHA-256', input);
      return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
    }

    // Lightweight fallback if subtle crypto is unavailable.
    let hash = 0;
    const text = String(value || '');
    for (let i = 0; i < text.length; i += 1) {
      hash = (hash << 5) - hash + text.charCodeAt(i);
      hash |= 0;
    }
    return `fallback-${Math.abs(hash).toString(16)}`;
  }

  function buildPayload(root, captureMode) {
    const body = extractLatestBodyText(root);
    if (!body || body.length < MIN_BODY_LENGTH) return null;

    const sourceType = detectSourceType(root);
    const title = extractDocumentTitle(root);
    const senderIdentity = extractSenderIdentity(root);
    const stableIdentity = makeSourceIdentity(sourceType, senderIdentity, title);
    const timestamp = extractLocalTimestamp(root);
    const normalizedBody = normalizeText(body);
    const signatureBase = [sourceType, stableIdentity, title, normalizedBody].join('\n---\n');

    return Promise.resolve(sha256Hex(signatureBase)).then((messageHash) => ({
      source_email: stableIdentity,
      message_body: normalizedBody,
      timestamp,
      source: sourceType,
      title,
      page_title: normalizeText(document.title || ''),
      page_url: location.href,
      message_hash: messageHash,
      capture_mode: captureMode,
      topic: title,
      product_keywords: [],
    }));
  }

  function setPanelState(state, detail) {
    const node = createMiniPanel();
    if (!node) return;
    const dot = node.querySelector('[data-qm-dot]');
    const miniDot = node.querySelector('[data-qm-mini-dot]');
    const status = node.querySelector('[data-qm-status]');
    const title = node.querySelector('[data-qm-title]');
    const mode = node.querySelector('[data-qm-mode]');
    if (!status) return;

    const palette = {
      idle: ['#64748b', '自动监听中', detail || '自动监听中。打开邮件详情页后，系统会在识别到正文时同步到业务线程。'],
      scanning: ['#f59e0b', '正在扫描', detail || '正在扫描当前页面，尝试识别最新沟通正文。'],
      captured: ['#22c55e', '同步成功', detail || '已同步到后端。请回到 QuoteMaster 控制台查看业务线程。'],
      duplicate: ['#3b82f6', '内容未变化', detail || '当前内容已经同步过，无需重复发送。'],
      empty: ['#94a3b8', '未识别到内容', detail || '尚未识别到可同步的邮件或沟通正文。'],
      error: ['#ef4444', '同步失败', detail || '同步失败，请打开 QuoteMaster 确认登录状态或查看后端配置。'],
    };

    const [color, titleText, statusText] = palette[state] || palette.idle;
    if (dot) dot.style.background = color;
    if (miniDot) miniDot.style.background = color;
    if (title) title.textContent = titleText;
    if (mode) mode.textContent = isPanelMinimized ? '最小化状态' : '展开状态';
    status.textContent = statusText;
  }
  function hasChromeStorage() {
    return typeof chrome !== 'undefined' && Boolean(chrome.storage && chrome.storage.local);
  }

  function readLocalFallback(key) {
    try {
      return window.localStorage.getItem(key) || '';
    } catch (_error) {
      return '';
    }
  }

  function writeLocalFallback(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch (_error) {
      // Some pages block localStorage. In-memory dedupe still protects this tab.
    }
  }
  async function readLastDeliveredHash() {
    if (!hasChromeStorage()) {
      return lastDeliveredHash || readLocalFallback(STORAGE_LAST_HASH_KEY);
    }

    try {
      const result = await chrome.storage.local.get([STORAGE_LAST_HASH_KEY]);
      return result?.[STORAGE_LAST_HASH_KEY] || '';
    } catch (error) {
      console.warn('[QuoteMaster] chrome.storage.local unavailable, using fallback cache:', error);
      return lastDeliveredHash || readLocalFallback(STORAGE_LAST_HASH_KEY);
    }
  }
  async function writeLastDeliveredState(hash, payload) {
    lastDeliveredHash = hash || lastDeliveredHash;

    if (!hasChromeStorage()) {
      writeLocalFallback(STORAGE_LAST_HASH_KEY, hash || '');
      writeLocalFallback(STORAGE_LAST_PAYLOAD_KEY, JSON.stringify(payload || {}));
      return;
    }

    try {
      await chrome.storage.local.set({
        [STORAGE_LAST_HASH_KEY]: hash,
        [STORAGE_LAST_PAYLOAD_KEY]: payload,
      });
    } catch (error) {
      console.warn('[QuoteMaster] failed to write chrome.storage.local, using fallback cache:', error);
      writeLocalFallback(STORAGE_LAST_HASH_KEY, hash || '');
      writeLocalFallback(STORAGE_LAST_PAYLOAD_KEY, JSON.stringify(payload || {}));
    }
  }
  function compactSyncError(message) {
    const text = normalizeText(message || '');
    if (!text) return '\u540c\u6b65\u5931\u8d25';
    if (/Missing QuoteMaster auth token|Authorization|Unauthorized|auth token|Bearer/i.test(text) || text.includes('\u672a\u8fde\u63a5 QuoteMaster \u8d26\u53f7')) {
      return '\u672a\u8fde\u63a5\u8d26\u53f7\uff1a\u8bf7\u5148\u6253\u5f00 QuoteMaster \u767b\u5f55\uff0c\u518d\u5237\u65b0\u90ae\u7bb1\u9875\u9762\u3002';
    }
    if (/Failed to fetch|NetworkError|Load failed/i.test(text) || text.includes('\u65e0\u6cd5\u8fde\u63a5\u672c\u5730\u540e\u7aef')) {
      return '\u65e0\u6cd5\u8fde\u63a5\u540e\u7aef\uff1a\u8bf7\u786e\u8ba4 npm run dev \u6b63\u5728\u8fd0\u884c\u3002';
    }
    if (text.includes('http://127.0.0.1:3000/api/ingest/communication') || text.includes('http://localhost:3000/api/ingest/communication')) {
      return '\u540e\u7aef\u540c\u6b65\u5931\u8d25\uff1a\u8bf7\u67e5\u770b QuoteMaster \u7ec8\u7aef\u65e5\u5fd7\u3002';
    }
    return text.length > 84 ? text.slice(0, 84) + '...' : text;
  }
  async function sendCapturedPayload(payload, captureMode) {
    if (!payload) {
      setPanelState('empty');
      return null;
    }

    const deliveredHash = await readLastDeliveredHash();
    if (captureMode === 'auto' && payload.message_hash && payload.message_hash === deliveredHash) {
      lastDeliveredHash = deliveredHash;
      setPanelState('duplicate', '\u5185\u5bb9\u5df2\u540c\u6b65\uff0c\u65e0\u9700\u91cd\u590d\u53d1\u9001');
      return {
        ok: true,
        skipped: true,
        payload,
      };
    }

    if (isSending) return null;
    isSending = true;

    setPanelState('scanning');
    console.log('[QuoteMaster] captured_data', payload);

    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        {
          type: BACKGROUND_EVENT,
          payload,
          capture_mode: captureMode,
        },
        async (response) => {
          isSending = false;

          if (chrome.runtime.lastError) {
            setPanelState('error', chrome.runtime.lastError.message || '无法连接后台');
            resolve({ ok: false, error: chrome.runtime.lastError.message || 'Runtime error' });
            return;
          }

          if (response?.ok) {
            lastSeenHash = payload.message_hash || lastSeenHash;
            lastDeliveredHash = payload.message_hash || lastDeliveredHash;
            await writeLastDeliveredState(payload.message_hash || '', payload);
            setPanelState('captured', '已同步到后端');
            resolve(response);
            return;
          }

          setPanelState('error', response?.display_error || compactSyncError(response?.error));
          resolve(response || { ok: false, error: 'Unknown response' });
        }
      );
    });
  }

  async function scanNow(captureMode = 'auto') {
    if (!isLikelyConversationPage()) {
      setPanelState('idle');
      return null;
    }

    const root = pickConversationRoot();
    if (!root) {
      setPanelState('empty', '未识别到可同步内容');
      return null;
    }

    const payload = await buildPayload(root, captureMode);
    if (!payload) {
      setPanelState('empty', '正文内容过短或尚未展开');
      return null;
    }

    if (payload.message_hash === lastSeenHash && captureMode === 'auto') {
      setPanelState('duplicate', '当前内容未变化');
      return {
        ok: true,
        skipped: true,
        payload,
      };
    }

    lastSeenHash = payload.message_hash || lastSeenHash;
    return sendCapturedPayload(payload, captureMode);
  }

  function scheduleScan() {
    window.clearTimeout(debounceTimer);
    debounceTimer = window.setTimeout(() => {
      scanNow('auto');
    }, DEBOUNCE_MS);
  }

  function shouldObserveMutations(mutations) {
    return mutations.some((mutation) => {
      if (mutation.type === 'characterData') return true;
      if (mutation.type !== 'childList') return false;
      return [...mutation.addedNodes].some((node) => {
        if (!(node instanceof Element)) return false;
        return Boolean(
          node.matches(
            [
              'div.a3s',
              '[role="article"]',
              'article',
              '[data-message-id]',
              '[data-pre-plain-text]',
              '[data-testid*="msg"]',
              '[data-testid*="message"]',
              '[aria-label*="message" i]',
              '[aria-label*="邮件"], [aria-label*="郵件"]',
              'main',
            ].join(',')
          ) || node.querySelector(
            [
              'div.a3s',
              '[role="article"]',
              'article',
              '[data-message-id]',
              '[data-pre-plain-text]',
              '[data-testid*="msg"]',
              '[data-testid*="message"]',
              '[class*="content" i]',
              '[class*="body" i]',
              '[class*="message" i]',
              '[class*="read" i]',
            ].join(',')
          )
        );
      });
    });
  }

  function mountObserver() {
    const target = document.body || document.documentElement;
    if (!target) return;

    if (mutationObserver) mutationObserver.disconnect();

    mutationObserver = new MutationObserver((mutations) => {
      if (!shouldObserveMutations(mutations)) return;
      if (!isLikelyConversationPage()) return;
      scheduleScan();
    });

    mutationObserver.observe(target, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.source !== "QUOTEMASTER_WEB_AUTH") return;
    if (event.data?.type !== "QUOTEMASTER_SET_AUTH") return;

    chrome.runtime.sendMessage({
      type: "QUOTEMASTER_SET_AUTH",
      payload: event.data.payload,
    });
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== FORCE_SYNC_EVENT) return false;

    scanNow('manual')
      .then((result) => {
        sendResponse({ ok: Boolean(result?.ok), payload: result?.payload || null, skipped: Boolean(result?.skipped) });
      })
      .catch((error) => {
        setPanelState('error', compactSyncError(error?.message || String(error)));
        sendResponse({ ok: false, error: error?.message || String(error) });
      });

    return true;
  });

  window.addEventListener('hashchange', scheduleScan);
  window.addEventListener('popstate', scheduleScan);
  window.addEventListener('focus', scheduleScan);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') scheduleScan();
  });

  if (IS_TOP_FRAME) createMiniPanel();
  if (IS_TOP_FRAME) setPanelState('idle');
  mountObserver();
  if (!isKnownNonConversationPage()) scheduleScan();

  window[GLOBAL_KEY] = {
    version: SCRIPT_VERSION,
    scanNow,
    cleanup() {
      window.clearTimeout(debounceTimer);
      if (mutationObserver) mutationObserver.disconnect();
      mutationObserver = null;
      if (panel?.parentNode) panel.parentNode.removeChild(panel);
      panel = null;
      isPanelMinimized = false;
    },
  };
})();
